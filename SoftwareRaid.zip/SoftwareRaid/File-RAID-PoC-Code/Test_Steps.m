Test Plan

Test case 1:  Delete Chunk1 -- Execute to show it will be restored and new image will be same as input image
Test case 2:  Delete Chunk2 -- Execute to show it will be restored and new image will be same as input image
Test case 3:  Delete Chunk3 -- Execute to show it will be restored and new image will be same as input image
Test case 4:  Delete Chunk4 -- Execute to show it will be restored and new image will be same as input image
Test case 5:  Delete Chunk5 -- Execute to show it will be restored and new image will be same as input image

Test case 6:  Delete Chunk1 + Corrupt chunk 2 (copy chunk 3 to chunk 2)
			-- Execute to show new image will be distorted